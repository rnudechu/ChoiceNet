
public class Service {

	String name;
	String type;
	String srcLocationAddrScheme;
	String srcLocationAddrValue;
	String dstLocationAddrScheme;
	String dstLocationAddrValue;
	Object property;
	String description;
	
	public Service(String name, String type, String srcLocationAddrScheme,
			String srcLocationAddrValue, String dstLocationAddrScheme,
			String dstLocationAddrValue, Object property, String description) {
		super();
		this.name = name;
		this.type = type;
		this.srcLocationAddrScheme = srcLocationAddrScheme;
		this.srcLocationAddrValue = srcLocationAddrValue;
		this.dstLocationAddrScheme = dstLocationAddrScheme;
		this.dstLocationAddrValue = dstLocationAddrValue;
		this.property = property;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSrcLocationAddrScheme() {
		return srcLocationAddrScheme;
	}

	public void setSrcLocationAddrScheme(String srcLocationAddrScheme) {
		this.srcLocationAddrScheme = srcLocationAddrScheme;
	}

	public String getSrcLocationAddrValue() {
		return srcLocationAddrValue;
	}

	public void setSrcLocationAddrValue(String srcLocationAddrValue) {
		this.srcLocationAddrValue = srcLocationAddrValue;
	}

	public String getDstLocationAddrScheme() {
		return dstLocationAddrScheme;
	}

	public void setDstLocationAddrScheme(String dstLocationAddrScheme) {
		this.dstLocationAddrScheme = dstLocationAddrScheme;
	}

	public String getDstLocationAddrValue() {
		return dstLocationAddrValue;
	}

	public void setDstLocationAddrValue(String dstLocationAddrValue) {
		this.dstLocationAddrValue = dstLocationAddrValue;
	}

	public Object getProperty() {
		return property;
	}

	public void setProperty(Object property) {
		this.property = property;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Service [name=" + name + ", type=" + type
				+ ", srcLocationAddrScheme=" + srcLocationAddrScheme
				+ ", srcLocationAddrValue=" + srcLocationAddrValue
				+ ", dstLocationAddrScheme=" + dstLocationAddrScheme
				+ ", dstLocationAddrValue=" + dstLocationAddrValue
				+ ", property=" + property + ", description=" + description + "]";
	}
	
}
