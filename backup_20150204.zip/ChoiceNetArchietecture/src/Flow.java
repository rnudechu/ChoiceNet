import java.util.LinkedList;


public class Flow {

	private LinkedList<Link> path;
	private int magnitude;
	private int delay;
	private int demandID;
	private FlowStatus status;
	
	public Flow(LinkedList<Link> path, int magnitude, int demandID) {
		super();
		this.path = path;
		this.magnitude = magnitude;
		this.demandID = demandID;
		status = FlowStatus.INACTIVE;
	}
	
	public LinkedList<Link> getPath() {
		return path;
	}
	public void setPath(LinkedList<Link> path) {
		this.path = path;
	}
	public int getMagnitude() {
		return magnitude;
	}
	public void setMagnitude(int bandwidth) {
		this.magnitude = bandwidth;
	}
	public int getDelay() {
		return delay;
	}
	public void setDelay(int delay) {
		this.delay = delay;
	}

	public int getDemandID() {
		return demandID;
	}

	public void setDemandID(int demandID) {
		this.demandID = demandID;
	}

	public FlowStatus getStatus() {
		return status;
	}

	public void setStatus(FlowStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Traffic [path=" + path + ", magnitude=" + magnitude
				+ ", delay=" + delay + "]";
	}
	
	
}
