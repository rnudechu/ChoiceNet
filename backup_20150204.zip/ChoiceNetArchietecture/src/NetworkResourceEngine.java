import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class NetworkResourceEngine {


	// stores all nodes in the system
	private  Node[] nodeArray;
	// contains a list of directed links which are in the system 
	private  Link[][] linkArrayOpticalPacket;
	private  Link[][] linkArrayOpticalCircuit;

	private  String configFile = "./config.properties";

	public NetworkResourceEngine()
	{

		createNodes();
		createLinks();
	}


	public void createNodes() 
	{

		Properties prop = new Properties();
		InputStream input = null;
		try {

			input = new FileInputStream(configFile);

			// load a properties file
			prop.load(input);

			// Supplying the Nodes into the system from the property file
			int numberOfNodes = 0;
			int opticalCircuitSwitchCapacity, opticalPacketSwitchCapacity;
			int nodeDelay;
			int opticalCircuitSwitchResidualCapacity, opticalPacketSwitchResidualCapacity;
			try
			{
				numberOfNodes = Integer.parseInt(prop.getProperty("numberOfNodes"));
			}
			catch(NumberFormatException e)
			{
				System.out.println("The config file "+configFile+" did not have a value for numberOfNodes");
				System.exit(1);
			}
			try
			{
				opticalCircuitSwitchCapacity = Integer.parseInt(prop.getProperty("opticalCircuitSwitchCapacity"));
			}
			catch(NumberFormatException e)
			{
				opticalCircuitSwitchCapacity = 100;
				System.out.println("WARNING: Value supplied for opticalCircuitSwitchCapacity was not an integer. " +
						"Default value of 100 will be used!");
			}
			try
			{
				opticalPacketSwitchCapacity = Integer.parseInt(prop.getProperty("opticalPacketSwitchCapacity"));
			}
			catch(NumberFormatException e)
			{
				opticalPacketSwitchCapacity = 100;
				System.out.println("WARNING: Value supplied for opticalPacketSwitchCapacity was not an integer. " +
						"Default value of 100 will be used!");
			}
			try
			{
				nodeDelay = Integer.parseInt(prop.getProperty("nodeDelay"));
			}
			catch(NumberFormatException e)
			{
				nodeDelay = 0;
				System.out.println("WARNING: Value supplied for nodeDelay was not an integer. " +
						"Default value of 0 will be used!");
			}
			try
			{
				opticalCircuitSwitchResidualCapacity = Integer.parseInt(prop.getProperty("opticalCircuitSwitchResidualCapacity"));
			}
			catch(NumberFormatException e)
			{
				opticalCircuitSwitchResidualCapacity = opticalCircuitSwitchCapacity;
				System.out.println("WARNING: Value supplied for opticalCircuitSwitchResidualCapacity was not an integer. " +
						"System will subsitute the same value as opticalCircuitSwitchCapacity");
			}

			try
			{
				opticalPacketSwitchResidualCapacity = Integer.parseInt(prop.getProperty("opticalPacketSwitchResidualCapacity"));
			}
			catch(NumberFormatException e)
			{
				opticalPacketSwitchResidualCapacity = opticalPacketSwitchCapacity;
				System.out.println("WARNING: Value supplied for opticalPacketSwitchResidualCapacity was not an integer. " +
						"System will subsitute the same value as opticalPacketSwitchCapacity");
			}
			nodeArray = new Node[numberOfNodes];
			linkArrayOpticalCircuit = new Link[numberOfNodes][numberOfNodes];
			linkArrayOpticalPacket = new Link[numberOfNodes][numberOfNodes];
			// Create new Nodes and store them inside the array
			for(int i= 0; i<numberOfNodes; i++)
			{
				Node newNode = new Node(opticalCircuitSwitchCapacity,opticalPacketSwitchCapacity,nodeDelay,opticalCircuitSwitchResidualCapacity,opticalPacketSwitchResidualCapacity,i);
				nodeArray[i] = newNode;
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void createLinks() 
	{

		Properties prop = new Properties();
		InputStream input = null;
		try {

			input = new FileInputStream(configFile);

			// load a properties file
			prop.load(input);

			// Supplying the Links into the system from the property file
			int numberOfLinks = 0;
			int linkCapacity = -1;
			int linkDelay = -1;
			int linkResidualCapacity = -1;
			try
			{
				linkCapacity = Integer.parseInt(prop.getProperty("linkCapacity"));
			}
			catch(NumberFormatException e)
			{
				linkCapacity = 100;
				System.out.println("WARNING: Value supplied for linkCapacity was not an integer. " +
						"Default value of 100 will be used!");
			}

			try
			{
				linkDelay = Integer.parseInt(prop.getProperty("linkDelay"));
				System.out.println("WARNING: Value supplied for linkDelay was not an integer. " +
						"System will subsitute the same value as linkDelay!");
			}
			catch(NumberFormatException e)
			{
				linkDelay = 0;
			}

			try
			{
				linkResidualCapacity = Integer.parseInt(prop.getProperty("linkResidualCapacity"));
			}
			catch(NumberFormatException e)
			{
				System.out.println("WARNING: Value supplied for linkResidualCapacity was not an integer. " +
						"Default value of 100 will be used!");
				linkResidualCapacity = 100;
			}
			String[] linkConnections = prop.getProperty("linkConnections").split(",");
			// parse through the links and attach the nodes together through a Link Object
			String[] singleConnection;
			numberOfLinks = linkConnections.length;
			// link array should be used as adjacency list array ... each index contains a node's possible links

			for(int i = 0; i < numberOfLinks; i++)
			{
				try
				{
					singleConnection = linkConnections[i].split("-");
					int head = Integer.parseInt(singleConnection[0]);
					int tail = Integer.parseInt(singleConnection[1]);

					//TODO: this sets the type of link that is created (circuit or packet) 
					Link newLinkCircuit = new Link(linkCapacity, linkDelay, linkResidualCapacity, configFile, nodeArray[head], nodeArray[tail], "Circuit");
					Link newLinkPacket = new Link(linkCapacity, linkDelay, linkResidualCapacity, configFile, nodeArray[head], nodeArray[tail], "Packet");
					linkArrayOpticalCircuit[head][tail] = newLinkCircuit;
					linkArrayOpticalPacket[head][tail] = newLinkPacket;
				}
				catch(ArrayIndexOutOfBoundsException e)
				{
					System.out.println("A requested link has a node that does not exist. The offending node is "+e.getMessage());
					System.out.println("Please resolve the problem in your config.properties file.");
					System.out.println("The system is now terminating.");
					System.exit(0);
				}
				catch(NumberFormatException e)
				{
					System.out.println("A requested link has a node that does not exist. The offending node has "+e.getMessage());
					System.out.println("Please resolve the problem in your config.properties file.");
					System.out.println("The system is now terminating.");
					System.exit(0);
				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public Node[] getNodeArray() {
		return nodeArray;
	}

	public String getConfigFile() {
		return configFile;
	}


	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}


	public void setNodeArray(Node[] nodeArray) {
		this.nodeArray = nodeArray;
	}

	public Link[][] getLinkArray(String linkType) {
		if(linkType.equals("Circuit"))
		{
			return linkArrayOpticalCircuit;
		}
		if(linkType.equals("Packet"))
		{
			return linkArrayOpticalPacket;
		}
		System.out.println("ERROR: Link type: "+linkType+" is unknown. Only acceptable link type are: Packet and Circuit");
		return null;
	}

	public void setLinkArray(Link[][] linkArray, String linkType) {
		if(linkType.equals("Circuit"))
		{
			this.linkArrayOpticalCircuit = linkArray;
		}
		if(linkType.equals("Packet"))
		{
			this.linkArrayOpticalPacket = linkArray;
		}
	}

	public boolean doesConnectionExist(int head, int tail, String linkType)
	{
		boolean result = false;
		Link[][] temp = getLinkArray(linkType);
		if(temp[head][tail] != null)
		{
			result = true;
		}
		return result;
	}

	public Link getConnectionProperty (int head, int tail, String linkType)
	{
		Link[][] temp = getLinkArray(linkType);
		Link myLink = temp[head][tail];
		return myLink;
	}

	public void printLinkArray(String linkType)
	{
		Link[][] temp = getLinkArray(linkType);
		int size = temp.length;
		Link currentLink;
		for(int i = 0; i<size;i++)
		{
			for(int j = 0; j<size;j++)
			{
				currentLink = temp[i][j];
				if(currentLink != null)
				{
					System.out.println(currentLink.toString());
				}
			}
		}
	}


	public boolean isInteger (String testObj, String message)
	{
		boolean result = false;
		try
		{
			Integer.parseInt(testObj);
			result = true;
		}
		catch(NumberFormatException e)
		{
			System.out.println(message);
		}
		return result;
	}
	
	public boolean isValidLinkType (String testObj, String message)
	{
		boolean result = false;
		try
		{
			Integer.parseInt(testObj);
			result = true;
		}
		catch(NumberFormatException e)
		{
			System.out.println(message);
		}
		return result;
	}

}
