
/**
 * @author Rob
 * Based on CardLayoutDemo.java on http://download.oracle.com/javase/tutorial/uiswing/examples/layout/CardLayoutDemoProject/src/layout/CardLayoutDemo.java
 * Similar to ServerDriver ... just a GUI Representation allows for sensorVisualization
 *
 */
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

public class MarketplaceGUI implements ActionListener {
	static Server server = new Server ();
	static int serverCount = 0;

	JPanel cards; //a panel that uses CardLayout
	final static String HOMEPANEL = "Card with Home Panel";

	public static int deviceDatabaseSize = 0;

	JButton searchBtn, purchaseBtn;  // application panel

	static JPanel applicationPanel, loginPanel;

	// test data
	private JLabel lblServerIpAddress;
	private JTextField serverIPAddressTxtFld;
	private JLabel lblClientDirections;
	private JLabel lblAdvertisementId;
	private JTextField purchaseTextField;
	private JLabel lblSource;
	private JLabel lblDestination;
	private JTextField sourceTextField;
	private JTextField destinationTextField;
	private JTextField txtBitsPerSecond;
	private JLabel lblBitsPerSecond;
	private JTextPane resultsPane;
	private static JLabel lblPurchaseStatus;
	private JButton viewPurchasesBtn;
	private JLabel lblToken;
	private JButton releasePurchaseBtn;
	private JTextField tokenTextField;
	private JButton viewAllPurchasesBtn;


	/**
	 * Create the GUI and show it.  For thread safety,
	 * this method should be invoked from the
	 * event dispatch thread.
	 */
	private static void createAndShowGUI() {
		//Create and set up the window.
		JFrame frmSensorServer = new JFrame("Marketplace Viewer");
		frmSensorServer.setBounds(200, 100, 647, 375);
		frmSensorServer.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		// Source https://tips4java.wordpress.com/2009/05/01/closing-an-application/
		frmSensorServer.addWindowListener( new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				JFrame frame = (JFrame)e.getSource();

				int result = JOptionPane.showConfirmDialog(
						frame,
						"Are you sure you want to exit the application?",
						"Exit Application",
						JOptionPane.YES_NO_OPTION);

				if (result == JOptionPane.YES_OPTION)
				{
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}
			}
		});

		//Create and set up the content pane.
		MarketplaceGUI gui = new MarketplaceGUI();
		gui.addComponentToPane(frmSensorServer.getContentPane());

		//Display the window.
		frmSensorServer.pack();
		frmSensorServer.setVisible(true);

		// create a list of devices already in the system
	}

	/**
	 * Creates all panes for the different user views.
	 * @param pane
	 */
	public void addComponentToPane(Container pane ) {
		JPanel panelHome = createLoginPanel();
		//Create the panel that contains the "cards".
		cards = new JPanel(new CardLayout());
		cards.add(panelHome, HOMEPANEL);
		pane.setPreferredSize(new Dimension(650, 380));
		pane.add(cards, BorderLayout.CENTER);
	}

	// change card by button selection

	public void actionPerformed(ActionEvent e) {
		//String errorMessage = "";
		// tries to open a file pertaining to its button
		if( e.getSource() == searchBtn)
		{
			if(e.getSource() == searchBtn)
			{
				String source = sourceTextField.getText().toString();
				String destination = destinationTextField.getText().toString();
				String magnitudeString = txtBitsPerSecond.getText().toString();
				int magnitude = -1;
				if(!magnitudeString.isEmpty())
				{
					magnitude = Integer.parseInt(magnitudeString);
				}
				String result = server.sendMarketplaceQuery(source, destination, magnitude);
				resultsPane.setText(result);
			}
		}
		// change card to reset both the sensor and device database
		if(e.getSource() == purchaseBtn)
		{
			// Delete the database file
			String token = purchaseTextField.getText().toString();
			if(!token.isEmpty())
			{
				// this is a hack ... and informs the marketplace rather than the advertiser about 
				// advertisement purchase
				server.sendMarketplacePurchase(token);
			}
		}
		if(e.getSource() == releasePurchaseBtn)
		{
			String purchaseID = tokenTextField.getText().toString();
			if(!purchaseID.isEmpty())
			{
				server.sendMarketplacePurgePurchase(purchaseID);
			}
		}
		if(e.getSource() == viewPurchasesBtn)
		{
			String result = server.retrieveActivePurchaseList();
			resultsPane.setText(result);
		}
		if(e.getSource() == viewAllPurchasesBtn)
		{
			String result = server.retrievePurchaseList();
			resultsPane.setText(result);
		}
	}

	/**
	 *  Returns a JPanel of the Login screen
	 * @return JPanel
	 */
	public JPanel createLoginPanel ()
	{
		JPanel loginPanel = new JPanel();
		loginPanel.setLayout(new FormLayout(new ColumnSpec[] {
				ColumnSpec.decode("6px"),
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.MIN_COLSPEC,
				FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
				FormFactory.MIN_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("max(74dlu;pref):grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("max(62dlu;default):grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("20px"),
				FormFactory.NARROW_LINE_GAP_ROWSPEC,
				RowSpec.decode("20px"),
				FormFactory.NARROW_LINE_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.NARROW_LINE_GAP_ROWSPEC,
				RowSpec.decode("24px"),
				FormFactory.UNRELATED_GAP_ROWSPEC,
				RowSpec.decode("26px"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("bottom:default"),}));

		lblServerIpAddress = new JLabel("Marketplace Address:");
		lblServerIpAddress.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblServerIpAddress, "3, 3, left, default");

		serverIPAddressTxtFld = new JTextField(Server.marketplaceRESTAPI);
		serverIPAddressTxtFld.setEditable(false);
		serverIPAddressTxtFld.setForeground(Color.BLACK);
		loginPanel.add(serverIPAddressTxtFld, "5, 3, 3, 1, fill, default");
		serverIPAddressTxtFld.setColumns(10);

		lblClientDirections = new JLabel("<html>Marketplace Address refers to the 'marketplaceRESTAPI' supplied in the config file.</html>");
		lblClientDirections.setFont(new Font("Dialog", Font.BOLD, 12));
		lblClientDirections.setForeground(Color.BLUE);
		loginPanel.add(lblClientDirections, "3, 7, 7, 1, center, center");

		lblSource = new JLabel("Source");
		lblSource.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblSource, "3, 11, left, default");

		sourceTextField = new JTextField();
		loginPanel.add(sourceTextField, "5, 11, fill, default");
		sourceTextField.setColumns(10);

		resultsPane = new JTextPane();
		resultsPane.setEditable(false);
		resultsPane.setFont(new Font("Dialog", Font.PLAIN, 10));
		loginPanel.add(resultsPane, "7, 11, 3, 9, fill, fill");

		lblDestination = new JLabel("Destination:");
		lblDestination.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblDestination, "3, 13, left, default");

		destinationTextField = new JTextField();
		loginPanel.add(destinationTextField, "5, 13, fill, default");
		destinationTextField.setColumns(10);

		lblBitsPerSecond = new JLabel("Bits Per Second");
		lblBitsPerSecond.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblBitsPerSecond, "3, 15, left, default");

		txtBitsPerSecond = new JTextField();
		loginPanel.add(txtBitsPerSecond, "5, 15, fill, default");
		txtBitsPerSecond.setColumns(10);

		searchBtn = new JButton("Search"); 
		searchBtn.setFont(new Font("Dialog", Font.BOLD, 12));
		searchBtn.addActionListener(this);

		loginPanel.add(searchBtn, "3, 17, 3, 1, fill, center");
				
				viewAllPurchasesBtn = new JButton("View All Purchases");
				viewAllPurchasesBtn.setFont(new Font("Dialog", Font.BOLD, 12));
				viewAllPurchasesBtn.addActionListener(this);
				loginPanel.add(viewAllPurchasesBtn, "3, 19");
		
				viewPurchasesBtn = new JButton("View Active Purchases");
				viewPurchasesBtn.setFont(new Font("Dialog", Font.BOLD, 12));
				viewPurchasesBtn.addActionListener(this);
				loginPanel.add(viewPurchasesBtn, "5, 19");

		lblAdvertisementId = new JLabel("Advertisement ID:");
		lblAdvertisementId.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblAdvertisementId, "3, 23, left, default");

		purchaseTextField = new JTextField();
		loginPanel.add(purchaseTextField, "5, 23, fill, default");
		purchaseTextField.setColumns(10);

		purchaseBtn = new JButton("Purchase");
		purchaseBtn.setFont(new Font("Dialog", Font.BOLD, 12));
		purchaseBtn.addActionListener(this);
		loginPanel.add(purchaseBtn, "7, 23");

		lblToken = new JLabel("Token:");
		lblToken.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(lblToken, "3, 25, left, default");

		tokenTextField = new JTextField();
		loginPanel.add(tokenTextField, "5, 25, fill, default");
		tokenTextField.setColumns(10);

		releasePurchaseBtn = new JButton("Release Purchase");
		releasePurchaseBtn.addActionListener(this);
		releasePurchaseBtn.setFont(new Font("Dialog", Font.BOLD, 12));
		loginPanel.add(releasePurchaseBtn, "7, 25, fill, center");

		lblPurchaseStatus = new JLabel("");
		lblPurchaseStatus.setFont(new Font("Dialog", Font.BOLD, 12));

		loginPanel.add(lblPurchaseStatus, "3, 29, 7, 1");

		return loginPanel;
	}

	public static void updateGUIPurchaseStatus()
	{
		String purchaseStatus = Server.purchaseStatus;
		if(!purchaseStatus.equals("None"))
		{
			if(purchaseStatus.equals("Success"))
			{
				lblPurchaseStatus.setText("Purchase successfully");
				lblPurchaseStatus.setForeground(new Color(0, 128, 0));
			}
			if(purchaseStatus.equals("Failed"))
			{
				lblPurchaseStatus.setText("Purchase failed");
				lblPurchaseStatus.setForeground(Color.RED);
			}
			lblPurchaseStatus.setText("<html>"+Server.purchaseStatusMessage+"</html>");
		}
	}

	public static void main(String[] args) {
		/* Use an appropriate Look and Feel */

		try {
			//UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		} catch (UnsupportedLookAndFeelException ex) {
			ex.printStackTrace();
		} catch (IllegalAccessException ex) {
			ex.printStackTrace();
		} catch (InstantiationException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		/* Turn off metal's use of bold fonts */
		UIManager.put("swing.boldMetal", Boolean.FALSE);

		//Schedule a job for the event dispatch thread:
		//creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});

		int loopCount = 0;
		while(true)
		{
			updateGUIPurchaseStatus();
			try {
				server.startServer();
			} catch (Exception e) {
				System.out.println("Server is already running at the given port");
			}
			System.out.println("Should see something here");

			loopCount++; // do not delete this count or suffer my wrath
			System.out.println("Loop count "+loopCount);
		}


	}

}
