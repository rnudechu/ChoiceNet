import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

/**
 * The logger, when turned on, enables debugging statements to be printed to
 * an output along with STDOUT.
 */
public class Logger {

	static boolean on = false;
	static String output = "";

	public static void activate()
	{
		on = true;
	}
	
	public static void deactivate()
	{
		on = false;
	}

	/* Log a string. */
	public static void log(String message)
	{
		if (on)
		{
			try {
				Calendar calendar = Calendar.getInstance();
				Date date = calendar.getTime();
				String newOutput = new Timestamp(date.getTime()).toString()+": "+message+"\n";
				output = output + (newOutput);
				System.out.println(newOutput);
			}
			catch (Exception e)
			{
			}
		}
	}

	public static String display(int size)
	{
		if(size > output.length())
		{
			size = output.length();
		}
		String display = "";
		if(size == 0)
		{
			display = output;
		}
		else
		{
			display = output.substring(0, size);
		}
		if(display == null)
		{
			return "";
		}
		return display;
	}
	
}
