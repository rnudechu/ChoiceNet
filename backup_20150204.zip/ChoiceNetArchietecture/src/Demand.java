import java.util.Date;
import java.util.LinkedList;

public class Demand {

	Node source;
	Node destination;
	int magnitude;
	int residualMagnitude;
	LinkedList<Flow> carriedTraffic;
	int id;
	long arrivalTime;
	DemandStatus status;
	String departureTime;
	int expirationTime;
	
	// keep a flag that keeps the status ... arrivedNotSatisfied, partiallySatisfied, Rejected, Blocked, satisfied(currently being carried), departed 
	// status could help with statistics (blocking/utilization)
	
	public Demand(Node source, Node destination, int magnitude) {
		this.id = -3; // default value
		this.source = source;
		this.destination = destination;
		this.magnitude = magnitude;
		this.residualMagnitude = magnitude;
		this.carriedTraffic = new LinkedList<Flow>();
		long lDateTime = new Date().getTime();
		this.arrivalTime = lDateTime;
		//this.arrivalTime = (new Timestamp(date.getTime())).toString();
		this.status = DemandStatus.ARRIVED;
		this.expirationTime = 10000;
	}

	public int getResidualMagnitude() {
		return residualMagnitude;
	}

	public void setResidualMagnitude(int residualMagnitude) {
		this.residualMagnitude = residualMagnitude;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Node getSource() {
		return source;
	}

	public void setSource(Node source) {
		this.source = source;
	}

	public Node getDestination() {
		return destination;
	}

	public void setDestination(Node destination) {
		this.destination = destination;
	}

	public int getMagnitude() {
		return magnitude;
	}

	public void setMagnitude(int magnitude) {
		this.magnitude = magnitude;
	}

	public LinkedList<Flow> getCarriedTraffic() {
		return carriedTraffic;
	}

	public void setCarriedTraffic(LinkedList<Flow> carriedTraffic) {
		this.carriedTraffic = carriedTraffic;
	}

	public DemandStatus getStatus() {
		return status;
	}

	public void setStatus(DemandStatus status) {
		this.status = status;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	
	public String getDemandUsage()
	{
		double magnitude = getMagnitude();
		double residual = getResidualMagnitude();
		double usage = (magnitude-residual)/magnitude;
		usage = usage * 100.0;
		return usage+" %";
	}
	
	public long getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(long arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getExpirationTime() {
		return expirationTime;
	}

	public void setExpirationTime(int expirationTime) {
		this.expirationTime = expirationTime;
	}

	@Override
	public String toString() {
		return "Demand [source=" + source + ", destination=" + destination
				+ ", magnitude=" + magnitude + ", residualMagnitude="
				+ residualMagnitude + ", carriedTraffic=" + carriedTraffic
				+ ", id=" + id + ", arrivalTime=" + arrivalTime + ", status="
				+ status + ", departureTime=" + departureTime
				+ ", expirationTime=" + expirationTime + "]";
	}

}
