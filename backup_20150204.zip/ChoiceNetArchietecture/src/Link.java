
public class Link {

	private int linkCapacity = -1;
	private int linkDelay = -1;
	private int linkResidualCapacity = -1;
	private Node head;
	private Node tail;
	private String linkType;
	
	public Link(int linkCapacity, int linkDelay, int linkResidualCapacity,
			String linkName, Node head, Node tail, String linkType) {
		super();
		this.linkCapacity = linkCapacity;
		this.linkDelay = linkDelay;
		this.linkResidualCapacity = linkResidualCapacity;
		this.head = head;
		this.tail = tail;
		this.linkType = linkType;
	}
	
	public int getLinkCapacity() {
		return linkCapacity;
	}
	public void setLinkCapacity(int linkCapacity) {
		this.linkCapacity = linkCapacity;
	}
	public int getLinkDelay() {
		return linkDelay;
	}
	public void setLinkDelay(int linkDelay) {
		this.linkDelay = linkDelay;
	}
	public int getLinkResidualCapacity() {
		return linkResidualCapacity;
	}
	public void setLinkResidualCapacity(int linkResidualCapacity) {
		this.linkResidualCapacity = linkResidualCapacity;
	}
	public Node getHead() {
		return head;
	}
	public void setHead(Node head) {
		this.head = head;
	}
	public Node getTail() {
		return tail;
	}
	public void setTail(Node tail) {
		this.tail = tail;
	}

	public String getLinkType() {
		return linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	@Override
	public String toString() {
		return "Link [linkCapacity=" + linkCapacity + ", linkDelay="
				+ linkDelay + ", linkResidualCapacity=" + linkResidualCapacity
				+ ", head=" + head + ", tail=" + tail + ", linkType="
				+ linkType + "]";
	}

}
