
public enum DemandStatus {
// arrivedNotSatisfied, partiallySatisfied, Rejected, Blocked, satisfied(currently being carried), departed
	ARRIVED, // demand has arrived but no flow has been associated
	BLOCKED,
	PARTIALLY_SATISFIED,
	SATISFIED, // demand has been satisfied
	DEPARTED,
	PURGED
}
