/**
 * Different Message Packet Type Code 
 * @author Robinson Udechukwu
 *
 */
public enum PurchaseType {
	INITIATED,
	ESTABLISHED,
	TERMINATED,
	PURGED,
	}