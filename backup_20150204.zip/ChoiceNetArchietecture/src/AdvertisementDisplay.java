
public class AdvertisementDisplay {

	private String considerationMethod;
	private int considerationValue;
	private String entityName;
	private String serviceName;
	private String advertiserAddress;
	private int advertiserPortAddress;
	private String advertiserAddressScheme;
	private String id;
	private String _rev;
	private String description;
	
	public AdvertisementDisplay(String considerationMethod, int considerationValue, String entityName,
			String serviceName, String advertiserAddress,
			int advertiserPortAddress, String advertiserAddressScheme,
			String id, String _rev, String description) {

		this.considerationMethod = considerationMethod;
		this.considerationValue = considerationValue;
		this.entityName = entityName;
		this.serviceName = serviceName;
		this.advertiserAddress = advertiserAddress;
		this.advertiserPortAddress = advertiserPortAddress;
		this.advertiserAddressScheme = advertiserAddressScheme;
		this.id = id;
		this._rev = _rev;
		this.description = description;
	}

	public String getConsiderationMethod() {
		return considerationMethod;
	}

	public void setConsiderationMethod(String considerationMethod) {
		this.considerationMethod = considerationMethod;
	}

	public int getConsiderationValue() {
		return considerationValue;
	}

	public void setConsiderationValue(int considerationValue) {
		this.considerationValue = considerationValue;
	}

	public String getEntityName() {
		return entityName;
	}


	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}


	public String getServiceName() {
		return serviceName;
	}


	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public String getAdvertiserAddress() {
		return advertiserAddress;
	}


	public void setAdvertiserAddress(String advertiserAddress) {
		this.advertiserAddress = advertiserAddress;
	}


	public int getAdvertiserPortAddress() {
		return advertiserPortAddress;
	}


	public void setAdvertiserPortAddress(int advertiserPortAddress) {
		this.advertiserPortAddress = advertiserPortAddress;
	}


	public String getAdvertiserAddressScheme() {
		return advertiserAddressScheme;
	}


	public void setAdvertiserAddressScheme(String advertiserAddressScheme) {
		this.advertiserAddressScheme = advertiserAddressScheme;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String get_rev() {
		return _rev;
	}

	public void set_rev(String _rev) {
		this._rev = _rev;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return String.format("(id=%s, serviceName=%s, description=%s,  considerationMethod=%s, considerationValue=%s, entityName=%s, advertiserAddressScheme=%s, advertiserAddress=%s, advertiserPortAddress=%s, _rev=%s)"
				, id, serviceName, description, considerationMethod, considerationValue, entityName, advertiserAddressScheme, advertiserAddress, advertiserPortAddress, _rev);
	}

}
