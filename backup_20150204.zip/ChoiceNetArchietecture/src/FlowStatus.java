
public enum FlowStatus {
	INACTIVE,
	CARRIED,
	REMOVED
}
