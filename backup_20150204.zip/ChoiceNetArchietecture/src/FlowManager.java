import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

public class FlowManager {

	NetworkResourceEngine nre;
	Map<Integer, ArrayList<RouteInformation>> discoveredRoutes;
	Map<Integer, Demand> demandList;
	private static FlowManager instance = new FlowManager();

	public FlowManager()
	{
		nre = new NetworkResourceEngine();
		demandList = new HashMap<Integer, Demand>();
		//TODO: rather than make discoveredRoutes contain the discovered route and its connection/link types
		discoveredRoutes = new HashMap<Integer, ArrayList<RouteInformation>>();
	}

	public static FlowManager getInstance() 
	{
		return instance;
	}

	// find available paths
	/*
	 * Populate the discovered routes for some demand
	 * - disable createFlow() and installFlow() from being called here; allows another process the ability to decide which route to take from ALL possible discovered routes
	 * 		from the discoveredRoutes structure
	 */
	public void findAvailableRoute(Demand requestedResource, boolean[] markedNodes, String routes, String linkType, String linkTypePath)
	{
		// iterate through the adjacency list to find an available route for some bandwidth
		// breadth first search
		Link[][] links = nre.getLinkArray(linkType);
		Link thisLink;
		ArrayList<RouteInformation> knownRoutes;
		int size = links.length;
		int source = requestedResource.getSource().getNodeID();
		int destination = requestedResource.getDestination().getNodeID();
		boolean[] searchedNodes = new boolean [size];
		if(markedNodes == null)
		{
			// reset the entry of discovered routes for this source
			if(discoveredRoutes.get(source)!=null)
			{
				System.out.println("here");
				discoveredRoutes.remove(source);
			}

			linkTypePath = linkType.substring(0,1)+"";
			routes = source+"";
			//TODO: create chain for link types
			markedNodes = new boolean [size];
			// insert Demand into Demand Mapping
			if(requestedResource.getId()==-3)
			{
				insertNewDemand(requestedResource, -1);
			}
		}
		else
		{
			linkTypePath = linkTypePath+"-"+linkType.substring(0,1);
		}
		markedNodes[source] = true;

		for(int i=0; i<size; i++)
		{
			//thisLink = links[source][i];
			System.out.println("check: src node:"+source+" dst node: "+i);
			thisLink = nre.getConnectionProperty(source, i, linkType);
			System.out.println(searchedNodes[i]);
			if(thisLink != null && (markedNodes[i]!=true || i<size))
			{
				searchedNodes[i] = true;
				System.out.println("temp: "+routes);
				if(markedNodes[i]!=true)
				{
					if(destination == i)
					{
						routes = routes+"-"+i;
						String[] components = routes.split("-");
						System.out.println("FIN: "+routes);
						int key = Integer.parseInt(components[0]);
						if(discoveredRoutes.get(key) != null)
						{
							knownRoutes = discoveredRoutes.get(key);
						}
						else
						{
							knownRoutes = new ArrayList<RouteInformation>();
						}
						RouteInformation newRoute = new RouteInformation(routes, linkTypePath);
						knownRoutes.add(newRoute);
						discoveredRoutes.put(key, knownRoutes);
						// WHAT IF you are not done traversing the source!!!
						return; // <== this will become a problem
					}
					// ignore self checking
					if( ((source != i) && (destination != i)) || (i<size) )
					{
						System.out.println("Recursive call");
						Node newSource = nre.getNodeArray()[i];
	
						requestedResource = new Demand(newSource, requestedResource.getDestination(), requestedResource.getMagnitude());
						//TODO: Could perform checking for route in both link types here
						if(linkType.equals("Circuit"))
						{
							findAvailableRoute(requestedResource, markedNodes, routes+"-"+i, "Circuit", linkTypePath);
						}
						if(linkType.equals("Packet"))
						{
							findAvailableRoute(requestedResource, markedNodes, routes+"-"+i, "Packet", linkTypePath);
						}
						if(linkType.equals("Mixed"))
						{
							findAvailableRoute(requestedResource, markedNodes, routes+"-"+i, "Circuit", linkTypePath);
							findAvailableRoute(requestedResource, markedNodes, routes+"-"+i, "Packet", linkTypePath);
						}
					}
				}
			}
		}
		// search for routes shared between the unique nodes found in the first round search
		//
		if(discoveredRoutes.get(source)!= null)
		{
			String[] components, lComponents;
			ArrayList<Integer> keyNode = new ArrayList<Integer>();
			Map<Integer,String> routeHead = new HashMap<Integer, String>();
			Map<Integer,String> routeTail = new HashMap<Integer, String>();
			Map<Integer,String> linkPathHead = new HashMap<Integer, String>();
			Map<Integer,String> linkPathTail = new HashMap<Integer, String>();
			String lPath = "";
			int key;
			boolean check;
			// find Key Nodes
			for(RouteInformation rInfo : discoveredRoutes.get(source))
			{
				components = rInfo.getRoutes().split("-");
				for(int i=0;i<components.length;i++)
				{
					key = Integer.parseInt(components[i]);
					if(key!=source && key!=destination && !keyNode.contains(key))
					{
						keyNode.add(key);
					}
				}
			}
			// determine their known routes and specify where they are the head node or a tail node
			for(RouteInformation rInfo : discoveredRoutes.get(source))
			{
				components = rInfo.getRoutes().split("-");
				check = false;
				for(int k : keyNode)
				{
					components = rInfo.getRoutes().split("-");
					lComponents = rInfo.getLinkType().split("-");
					routes = "";
					lPath = "";
					for(int i=0;i<components.length;i++)
					{
						routes += components[i]+"-";
						if(i<lComponents.length)
						{
							lPath += lComponents[i]+"-";
						}
						key = Integer.parseInt(components[i]);
						if(k == key)
						{
							check = true;
							routeTail.put(k, routes);
							linkPathTail.put(k, lPath);
							routes = k+"-";
							if(i<lComponents.length)
							{
								lPath = lComponents[i]+"-";
							}
						}
					}
					if(check)
					{
						routes = routes.substring(0, routes.length()-1);
						lPath = lPath.substring(0, lPath.length()-1);
						routeHead.put(k, routes);
						linkPathHead.put(k, lPath);
					}
				}
			}
			discoveredRoutes.remove(source);
			knownRoutes = new ArrayList<RouteInformation>();
			for(int j : keyNode)
			{
				for(int k : keyNode)
				{
					thisLink = nre.getConnectionProperty(j, k, linkType);
					// to remove loop, check the links
					if(nre.doesConnectionExist(j, k, linkType) && loopPreventionMechanism(routeTail.get(j), routeHead.get(k)))
					{
						routes = routeTail.get(j)+routeHead.get(k);
						lPath = linkPathTail.get(j)+linkPathHead.get(k);
						RouteInformation newRoute = new RouteInformation(routes, lPath);
						knownRoutes.add(newRoute);
						discoveredRoutes.put(source, knownRoutes);
//						System.out.println(routes + " "+lPath);
					}
				}
			}
//			System.out.println(routeTail);
//			System.out.println(routeHead);
//			System.out.println(linkPathTail);
//			System.out.println(linkPathHead);
		}
	}

	/*
	 * validateFlow is intended to test check whether flow will work
	 */
	public boolean installFlow(Flow trafficPattern)
	{
		boolean result = true;
		// read traffic pattern; retrieve the nodes and the cost for the traffic 
		int trafficCost = trafficPattern.getMagnitude(); 
		// for each node, verify there is a connection between it and the next node
		int headNode = -1;
		int tailNode = -1;
		int linkHeadResidualCapacity = -1;
		int linkTailResidualCapacity = -1;
		Demand requestedDemand = demandList.get(trafficPattern.getDemandID());
		// check whether the flow is associated with the demand ... chance that createFlow did not include the flow as carried traffic
		if(!requestedDemand.getCarriedTraffic().contains(trafficPattern))
		{
			System.out.println("INFO: Flow is not included in a demand's carried traffic list!");
			System.out.println(trafficPattern);
			System.out.println("==========================");
			return false;
		}

		DemandStatus demandStatus = DemandStatus.ARRIVED;
		int i = 0;
		String linkType = "";
		// size -1 to ignore checking the path following the node 
		for(Link connections : trafficPattern.getPath())
		{
			// technically the link type should remain the same for the entire chain ... wait this is FALSE ... you can make path from a mixture of link types
			linkType = connections.getLinkType();
			headNode = connections.getHead().getNodeID();
			tailNode = connections.getTail().getNodeID();
			if(nre.doesConnectionExist(headNode, tailNode, linkType))
			{
				//System.out.println("There is a connection between "+headNode+" and "+tailNode);
				// I could check whether the resources are available here
				Link thisLink = nre.getConnectionProperty(headNode, tailNode, linkType);
				if(linkType.equals("Circuit"))
				{
					linkHeadResidualCapacity = thisLink.getHead().getOpticalCircuitSwitchResidualCapacity();
					linkTailResidualCapacity = thisLink.getTail().getOpticalCircuitSwitchResidualCapacity();
				}
				if(linkType.equals("Packet"))
				{
					linkHeadResidualCapacity = thisLink.getHead().getOpticalPacketSwitchResidualCapacity();
					linkTailResidualCapacity = thisLink.getTail().getOpticalPacketSwitchResidualCapacity();
				}

				if(thisLink.getLinkCapacity()<trafficCost)
				{
					// perhaps here is here is where a traffic can split to go another route
					// TODO: recalculate a new path
					System.out.println("TEMP ERROR: Not enough capacity between nodes "+headNode+" and "+tailNode);
					result = false;
				}
				if(i == 0)
				{
					if(linkHeadResidualCapacity<trafficCost)
					{
						System.out.println("WARNING: Flow request exceeds node "+headNode+" capacity."+
								"Flow magnitude is "+trafficCost+" while node only has "+linkHeadResidualCapacity);
						result = false;
					}
				}
				if(linkTailResidualCapacity<trafficCost)
				{
					System.out.println("WARNING: Flow request exceeds node "+headNode+" capacity."+
							"Flow magnitude is "+trafficCost+" while node only has "+linkTailResidualCapacity);
					result = false;
				}
			}
			else
			{
				System.out.println("There is no connection between "+headNode+" and "+tailNode);
				result = false;
			}

		}

		// if the outcome still reports true then you should attempt to allocate resources from the nodes
		if(result)
		{
			trafficPattern.setStatus(FlowStatus.CARRIED);
			// loop through the nodes
			int capacity = 0;
			boolean checkHead = true;
			LinkedList<Link> singleTrafficPath = new LinkedList<Link>();
			for(Link connections : trafficPattern.getPath())
			{
				headNode = connections.getHead().getNodeID();
				tailNode = connections.getTail().getNodeID();
				linkType = connections.getLinkType();
				Link thisLink = nre.getConnectionProperty(headNode, tailNode, linkType);
				if(linkType.equals("Circuit"))
				{
					linkHeadResidualCapacity = thisLink.getHead().getOpticalCircuitSwitchResidualCapacity();
					linkTailResidualCapacity = thisLink.getTail().getOpticalCircuitSwitchResidualCapacity();
				}
				if(linkType.equals("Packet"))
				{
					linkHeadResidualCapacity = thisLink.getHead().getOpticalPacketSwitchResidualCapacity();
					linkTailResidualCapacity = thisLink.getTail().getOpticalPacketSwitchResidualCapacity();
				}
				// link capacity
				capacity = thisLink.getLinkResidualCapacity() - trafficCost;
				thisLink.setLinkResidualCapacity(capacity);
				// node capacity
				if(checkHead)
				{
					// if statement guarentees head node is checked only once
					capacity = linkHeadResidualCapacity - trafficCost;
					connections.getHead().setNodeResidualCapacity(capacity, linkType);
					checkHead = false;
				}
				capacity = linkTailResidualCapacity - trafficCost;
				connections.getTail().setNodeResidualCapacity(capacity, linkType);
				// add to the link to the traffic path
				singleTrafficPath.add(thisLink);
			}
			// insert the traffic path to that array list
			if(singleTrafficPath != null)
			{
				trafficPattern.setPath(singleTrafficPath);
			}
			// update the demand's residual satisfied magnitude 
			capacity = requestedDemand.getResidualMagnitude() - trafficCost;
			requestedDemand.setResidualMagnitude(capacity);
			// change the default value for the demand's status
			if(requestedDemand.getResidualMagnitude() > 0)
			{
				demandStatus = DemandStatus.PARTIALLY_SATISFIED;
				//System.exit(0);
				//TODO: Another Flow needs to be found to satisfy this residual magnitude ...
			}
			// update status if this flow will satisfy the demand
			if(requestedDemand.getResidualMagnitude() == 0)
			{
				demandStatus = DemandStatus.SATISFIED;
			}
		}
		else
		{
			demandStatus = DemandStatus.BLOCKED;
		}
		requestedDemand.setStatus(demandStatus);
		return result;
	}

	public boolean deleteFlow(Flow trafficPattern)
	{
		boolean result = true;
		// read traffic pattern; retrieve the nodes and the cost for the traffic 
		int trafficCost = trafficPattern.getMagnitude(); 
		// for each node, verify there is a connection between it and the next node
		int headNode = -1;
		int tailNode = -1;
		int linkHeadResidualCapacity = -1;
		int linkTailResidualCapacity = -1;
		int capacity = 0;
		boolean checkHead = true;
		String linkType = "";
		// size -1 to ignore checking the path following the node 
		for(Link connections : trafficPattern.getPath())
		{
			linkType = connections.getLinkType();
			headNode = connections.getHead().getNodeID();
			tailNode = connections.getTail().getNodeID();
			Link thisLink = nre.getConnectionProperty(headNode, tailNode, linkType);
			if(linkType.equals("Circuit"))
			{
				linkHeadResidualCapacity = thisLink.getHead().getOpticalCircuitSwitchResidualCapacity();
				linkTailResidualCapacity = thisLink.getTail().getOpticalCircuitSwitchResidualCapacity();
			}
			if(linkType.equals("Packet"))
			{
				linkHeadResidualCapacity = thisLink.getHead().getOpticalPacketSwitchResidualCapacity();
				linkTailResidualCapacity = thisLink.getTail().getOpticalPacketSwitchResidualCapacity();
			}
			capacity = thisLink.getLinkResidualCapacity() + trafficCost;
			if(capacity<=thisLink.getLinkCapacity())
			{
				thisLink.setLinkResidualCapacity(capacity);
			}
			else
			{
				result = false;
				System.err.println("Failed attempt in restoring link capacity between "+headNode+" and "
						+ tailNode);
			}
			if(checkHead)
			{
				// if statement guarentees head node is checked only once
				capacity = linkHeadResidualCapacity + trafficCost;
				if(capacity<=connections.getHead().getNodeCapacity())
				{
					connections.getHead().setNodeResidualCapacity(capacity, linkType);
				}
				else
				{
					result = false;
					System.err.println("Failed attempt in restoring node "+headNode+" capacity.");
				}
				checkHead = false;
			}
			capacity = linkTailResidualCapacity + trafficCost;
			if(capacity<=connections.getTail().getNodeCapacity())
			{
				connections.getTail().setNodeResidualCapacity(capacity, linkType);
			}
			else
			{
				result = false;
				System.err.println("Failed attempt in restoring node "+tailNode+" capacity.");
			}
		}

		if(result)
		{
			trafficPattern.setStatus(FlowStatus.REMOVED);
		}
		return result;
	}

	public void insertNewDemand (Demand requestedResource, int demandID)
	{
		// save new Demand
		if(demandID == -1)
		{
			// ensures that the demand ID will not be set to zero; the default value for all new demands
			demandID = demandList.size()+1;
			// guarantee that this ID has not already been taken
			demandID = findAvailableDemandID(demandID);
		}
		if(demandID == -2)
		{
			System.out.println("ERROR: Demand ID resulted into -2 a value reserved for " +
					"Advertisement's flows. System will now be exiting.");
			System.exit(0);
		}
		requestedResource.setId(demandID);
		demandList.put(demandID, requestedResource);
	}

	public int findAvailableDemandID (int demandID)
	{
		Random generator = new Random(); 
		while(demandList.get(demandID) != null)
		{
			demandID = generator.nextInt(1000000) + 1;	
		}

		return demandID;
	}

	public void loadRoutes()
	{
		Node[] allNodes = nre.getNodeArray();
		Demand myDemand;
		int size = allNodes.length;
		for(int i=0; i<size; i++)
		{
			for(int j=0; j<size; j++)
			{
				if(i != j)
				{
					myDemand = new Demand(allNodes[i], allNodes[j], 0);
					findAvailableRoute(myDemand, null, "", "Circuit","");
					findAvailableRoute(myDemand, null, "", "Packet","");
				}
			}
		}
	}

	public Flow createFlow(String pathString, int magnitude, int demandID, String linkTypePath)
	{
		LinkedList<Link> path = new LinkedList<Link>(); 
		String[] routeMap = pathString.split("-");
		String[] linkTypeMap = linkTypePath.split("-");
		int pathSize = routeMap.length;
		System.out.println(pathSize+" "+linkTypeMap.length);
		int headNode = -1;
		int tailNode = -1;
		String linkType = "";
		// in one case this function creates 
		for (int j =0; j<pathSize-1; j++)
		{
			headNode = Integer.parseInt(routeMap[j]);
			tailNode = Integer.parseInt(routeMap[j+1]);
			if(linkTypeMap[j].equals("C"))
			{
				linkType = "Circuit";
			}
			if(linkTypeMap[j].equals("P"))
			{
				linkType = "Packet";
			}
			Link connection = nre.getConnectionProperty(headNode, tailNode, linkType);
			if(connection != null)
			{
				path.add(connection);
			}
			else
			{
				System.out.println("ERROR: A link along this path "+pathString+" has no connection! " +
						"If you are loading traffic from the config file. Please resolve this problem to move forward. " +
						"The system will now terminate!");
				System.exit(0);
			}
		}
		Flow suggestedTrafficRoute = new Flow(path, magnitude, demandID);
		int flowManitude = 0;
		// ignore in the case of flow object creation for Advertisements
		if(demandID != -2)
		{
			// associate this flow to the demand with the match demand id
			Demand correspondingDemand = demandList.get(demandID);
			if(correspondingDemand != null)
			{
				if(correspondingDemand.getCarriedTraffic() != null)
				{
					for(Flow tempFlow : correspondingDemand.getCarriedTraffic())
					{
						flowManitude += tempFlow.getMagnitude();
					}
					flowManitude += suggestedTrafficRoute.getMagnitude();
					if(flowManitude<=correspondingDemand.getMagnitude())
					{
						correspondingDemand.getCarriedTraffic().add(suggestedTrafficRoute);
					}
					else
					{
						System.out.println("INFO: Flow "+suggestedTrafficRoute.getDemandID()+" has a magnitude "+
								suggestedTrafficRoute.getMagnitude()+" that exceeds the demand's "+correspondingDemand.getMagnitude()+
								" so flow was not included with the demand");
						System.out.println("==========================");

					}
				}

			}
			else
			{
				System.out.println("ERROR: Flow "+suggestedTrafficRoute.getDemandID()+" has been created but there is no matching demand. " +
						"System is exiting, check your config file.");
				System.exit(0);

			}
		}
		return suggestedTrafficRoute;
	}

	/*
	 * Reloads the system from a previous state based on a configuration file
	 */
	public void reloadSystem()
	{
		Properties prop = new Properties();
		InputStream input = null;
		try {

			input = new FileInputStream(nre.getConfigFile());

			// load a properties file
			prop.load(input);
			String[] trafficProperties;
			String[] trafficPatterns;
			String[] trafficNodes;
			int source, destination, magnitude, demandID;
			String eMessage, originalPattern, linkTypePath;
			Node[] allNodes = nre.getNodeArray();
			Node srcNode, dstNode;
			boolean result;

			// Supplying the requested demands into the system from the property file
			String requestedDemands = prop.getProperty("requestedDemands");
			trafficProperties = requestedDemands.split(";");
			for(String trafficPattern : trafficProperties)
			{
				originalPattern = trafficPattern;
				trafficPatterns = trafficPattern.split("\\|");

				trafficNodes = trafficPatterns[0].split(",");

				eMessage = "ERROR: Value supplied as source for requestedDemands: "+originalPattern+" is not an integer. This demand will not be created!";	
				result =  nre.isInteger(trafficNodes[0], eMessage);

				eMessage = "ERROR: Value supplied as destination for requestedDemands: "+originalPattern+" is not an integer. This demand will not be created!";	
				result = result && nre.isInteger(trafficNodes[1], eMessage);

				eMessage = "ERROR: Value supplied as magnitude for requestedDemands: "+originalPattern+" is not an integer. This demand will not be created!";
				result = result && nre.isInteger(trafficPatterns[1], eMessage);

				eMessage = "ERROR: Value supplied as demandID for requestedDemands: "+originalPattern+" is not an integer. This demand will not be created!";	
				result = result && nre.isInteger(trafficPatterns[2], eMessage);

				if(result)
				{
					magnitude = Integer.parseInt(trafficPatterns[1]); 
					demandID = Integer.parseInt(trafficPatterns[2]);
					source = Integer.parseInt(trafficNodes[0]);
					destination = Integer.parseInt(trafficNodes[1]);
					srcNode = allNodes[source];
					dstNode = allNodes[destination];
					Demand requestedResource = new Demand(srcNode, dstNode, magnitude);
					insertNewDemand(requestedResource, demandID);
				}
			}

			// Supplying the current flows into the system from the property file
			String currentFlows = prop.getProperty("currentFlows");
			trafficProperties = currentFlows.split(";");
			for(String trafficPattern : trafficProperties)
			{
				originalPattern = trafficPattern;
				trafficPatterns = trafficPattern.split("\\|");
				eMessage = "ERROR: Value supplied as magnitude for currentFlow: "+originalPattern+" is not an integer. This flow will not be created!";
				result = nre.isInteger(trafficPatterns[1], eMessage);

				eMessage = "ERROR: Value supplied as demandID for currentFlow: "+originalPattern+" is not an integer. This flow will not be created!";	
				result = result && nre.isInteger(trafficPatterns[2], eMessage);

				// Check whether Link type when creating a flow
				//eMessage = "ERROR: Value supplied as demandID for currentFlow: "+originalPattern+" is not an integer. This flow will not be created!";	
				if(result)
				{
					magnitude = Integer.parseInt(trafficPatterns[1]);
					demandID = Integer.parseInt(trafficPatterns[2]);
					linkTypePath = trafficPatterns[3];
					Flow trafficFlow = createFlow(trafficPatterns[0], magnitude, demandID, linkTypePath);
					installFlow(trafficFlow);
				}
			}

			// Supplying the expired flows into the system from the property file
			String expiredFlows = prop.getProperty("expiredFlows");
			trafficProperties = expiredFlows.split(";");
			for(String trafficPattern : trafficProperties)
			{
				originalPattern = trafficPattern;
				trafficPatterns = trafficPattern.split("\\|");
				eMessage = "ERROR: Value supplied as magnitude for expiredFlows: "+originalPattern+" is not an integer. This flow will not be created!";
				result = nre.isInteger(trafficPatterns[1], eMessage);

				eMessage = "ERROR: Value supplied as demandID for expiredFlows: "+originalPattern+" is not an integer. This flow will not be created!";	
				result = result && nre.isInteger(trafficPatterns[2], eMessage);

				// Check whether Link type when creating a flow
				//eMessage = "ERROR: Value supplied as demandID for currentFlow: "+originalPattern+" is not an integer. This flow will not be created!";	
				if(result)
				{
					magnitude = Integer.parseInt(trafficPatterns[1]);
					demandID = Integer.parseInt(trafficPatterns[2]);
					linkTypePath = trafficPatterns[3];
					if(!linkTypePath.equals("B"))
					{
						Flow trafficFlow = createFlow(trafficPatterns[0], magnitude, demandID, linkTypePath);
						Demand requestedDemand = demandList.get(demandID);
						requestedDemand.setStatus(DemandStatus.PURGED);
						trafficFlow.setStatus(FlowStatus.REMOVED);
					}
					else
					{
						Demand requestedDemand = demandList.get(demandID);
						requestedDemand.setStatus(DemandStatus.BLOCKED);
					}

				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void saveSystem()
	{
		Properties prop = new Properties();
		OutputStream output = null;
		java.util.Date date= new java.util.Date();
		String timestamp = (new Timestamp(date.getTime())).toString();
		timestamp = timestamp.replace(" ", "_");
		try {

			output = new FileOutputStream("config_"+timestamp+".properties");

			// Nodes
			Node[] allNodes = nre.getNodeArray();
			int numberOfNodes = allNodes.length;

			String nodeCapacity = "";
			String nodeDelay = "";
			String nodeResidualCapacity = "";
			prop.setProperty("numberOfNodes", Integer.toString(numberOfNodes));
			// loop through the nodes and get a list of their capacity, delay, residual capacity
			for(int i = 0; i < numberOfNodes; i++)
			{
				nodeCapacity += allNodes[i].getNodeCapacity()+",";  
				nodeDelay += allNodes[i].getNodeDelay()+",";  
				nodeResidualCapacity += allNodes[i].getNodeResidualCapacity()+",";  
			}
			nodeCapacity = nodeCapacity.substring(0, nodeCapacity.length()-1);
			nodeDelay = nodeDelay.substring(0, nodeDelay.length()-1);
			nodeResidualCapacity = nodeResidualCapacity.substring(0, nodeResidualCapacity.length()-1);
			// set the properties value
			prop.setProperty("nodeCapacity", nodeCapacity);
			prop.setProperty("nodeDelay", nodeDelay);
			prop.setProperty("nodeResidualCapacity", nodeResidualCapacity);

			// Links
			String linkConnections = "";
			String linkCapacity = "";
			String linkDelay = "";
			String linkResidualCapacity = "";
			Link thisLink;
			for(int i = 0; i < numberOfNodes; i++)
			{
				for(int j = 0; j < numberOfNodes; j++)
				{
					if(nre.doesConnectionExist(i, j, "Circuit"))
					{
						linkConnections += i+"-"+j+",";
						thisLink = nre.getConnectionProperty(i, j, "Circuit");
						linkCapacity += thisLink.getLinkCapacity()+",";  
						linkDelay += thisLink.getLinkDelay()+",";  
						linkResidualCapacity += thisLink.getLinkResidualCapacity()+",";
					}
					if(nre.doesConnectionExist(i, j, "Packet"))
					{
						linkConnections += i+"-"+j+",";
						thisLink = nre.getConnectionProperty(i, j, "Packet");
						linkCapacity += thisLink.getLinkCapacity()+",";  
						linkDelay += thisLink.getLinkDelay()+",";  
						linkResidualCapacity += thisLink.getLinkResidualCapacity()+",";
					}
				} 
			}
			linkConnections = linkConnections.substring(0, linkConnections.length()-1);
			linkCapacity = linkCapacity.substring(0, linkCapacity.length()-1);
			linkDelay = linkDelay.substring(0, linkDelay.length()-1);
			linkResidualCapacity = linkResidualCapacity.substring(0, linkResidualCapacity.length()-1);
			// set the properties value
			prop.setProperty("linkConnections", linkConnections);
			prop.setProperty("linkCapacity", linkCapacity);
			prop.setProperty("linkDelay", linkDelay);
			prop.setProperty("linkResidualCapacity", linkResidualCapacity);

			// Demands
			String source = "";
			String destination = "";
			String magnitude = "";
			String demandID = "";
			String requestedDemands = "";
			String currentFlows = "";
			boolean result;
			for(Demand thisDemand : demandList.values())
			{
				source = Integer.toString(thisDemand.getSource().getNodeID());
				destination = Integer.toString(thisDemand.getDestination().getNodeID());
				magnitude = Integer.toString(thisDemand.getMagnitude());
				demandID = Integer.toString(thisDemand.getId());
				requestedDemands += source+","+destination+"|"+magnitude+"|"+demandID+";";
				// loop through linked list to get the path
				for(Flow thisFlow : thisDemand.getCarriedTraffic())
				{
					result = true;
					for(Link currLink : thisFlow.getPath())
					{
						if(result)
						{
							currentFlows += Integer.toString(currLink.getHead().getNodeID());
							result = false;
						}
						currentFlows += "-"+Integer.toString(currLink.getTail().getNodeID());
					}
					currentFlows += "|"+Integer.toString(thisFlow.getMagnitude())+"|"+Integer.toString(thisFlow.getDemandID())+";";
				}
			}
			requestedDemands = requestedDemands.substring(0, requestedDemands.length()-1);
			currentFlows = currentFlows.substring(0, currentFlows.length()-1);
			// set the properties value
			prop.setProperty("requestedDemands", requestedDemands);
			prop.setProperty("currentFlows", currentFlows);

			// Flows

			// set the properties value

			// save properties to project root folder
			prop.store(output, null);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public void enterRequestedDemand(Demand requestedDemand, String flowProperty){
		int source = requestedDemand.getSource().getNodeID();
		int magnitude = requestedDemand.getMagnitude();
		String routes, linkTypePath = "";
		System.out.println("===> Source: "+source+" Destination: "+requestedDemand.getDestination().getNodeID());
		findAvailableRoute(requestedDemand, null, "", flowProperty,"");
		System.out.println("===> kubzsjkgfn");
		if(discoveredRoutes.get(source)!= null)
		{
			// search based on param: flowProperty and see if route is available
			for(RouteInformation info : discoveredRoutes.get(source))
			{
				if(info.getProperty().equals(flowProperty) && requestedDemand.getResidualMagnitude()>0)
				{
					int demandID = requestedDemand.getId();
					routes = info.getRoutes();
					linkTypePath = info.getLinkType();
					// attempt the first route if it is available
					Flow suggestedTrafficRoute = createFlow(routes, magnitude, demandID, linkTypePath);
					if(requestedDemand.getCarriedTraffic().contains(suggestedTrafficRoute))
					{
						installFlow(suggestedTrafficRoute);
					}
					printAllDemandList();
				}
			}
		}
		else
		{
			requestedDemand.setStatus(DemandStatus.BLOCKED);
			System.out.println("WARNING: A demand was issued that has no path. This Demand should be labeled as BLOCKED");
			System.out.println(requestedDemand);
		}
	}

	public void removeExpiredDemands()
	{
		long time, currentTime;
		currentTime = new Date().getTime();
		for (Demand myDemand : demandList.values())
		{
			time = myDemand.getArrivalTime()+myDemand.getExpirationTime();
			if(currentTime>time && (myDemand.getStatus().equals(DemandStatus.SATISFIED) || myDemand.getStatus().equals(DemandStatus.DEPARTED)) )
			{
				System.out.println("Demand "+myDemand.getId()+" has been departed ...");
				myDemand.setStatus(DemandStatus.DEPARTED);
				for(Flow myFlow : myDemand.getCarriedTraffic())
				{
					deleteFlow(myFlow);
				}
				System.out.println("Demand "+myDemand.getId()+" has been purged ...");
				myDemand.setStatus(DemandStatus.PURGED);
				printAllDemandList();
			}
		}
	}

	public boolean loopPreventionMechanism (String linkA, String linkB)
	{
		String[] arrA = linkA.split("-");
		String[] arrB = linkB.split("-");
		for(String aContent : arrA)
		{
			for(String bContent : arrB)
			{
				if(aContent.equals(bContent))
				{
					return false;
				}
			}
		}
		
		return true;
	}
	
	// random number generator to define if new traffic should be generated ()
	//	- Yes: 	then generate a random amount time demand lives ()
	//			create demand and attempt to enter the request
	//			randomly select topology makeup
	public void generateRandomDemand ()
	{
		Node[] allNodes = getNRE().getNodeArray();
		Node source, destination;
		Demand requestedResource;
		Random rand = new Random();
		int max = 10;
		int min = 1;
		int randomNum, randomMagnitude, randomSource, randomDestination;
		int numNodes = allNodes.length;
		String linkType;
		randomNum = rand.nextInt((max - min) + 1) + min;
		if(randomNum>8)
		{
			randomSource = rand.nextInt((numNodes));
			randomDestination = rand.nextInt((numNodes));
			if(randomSource != randomDestination)
			{
				source = allNodes[randomSource];
				destination = allNodes[randomDestination];
				randomMagnitude = rand.nextInt((100 - 1) + 1) + 1;
				requestedResource = new Demand(source,destination,randomMagnitude);
				randomNum = rand.nextInt((60000 - 10000) + 1) + 10000;
				requestedResource.setExpirationTime(randomNum);
				randomNum = rand.nextInt((max - min) + 1) + min;
				if(randomNum>5)
				{
					linkType = "Circuit";
				}
				else
				{
					linkType = "Packet";
				}
				enterRequestedDemand(requestedResource, linkType);
			}
		}
	}
	
	public Map<Integer, ArrayList<RouteInformation>> getDiscoveredRoutes() {
		return discoveredRoutes;
	}

	public void setDiscoveredRoutes(Map<Integer, ArrayList<RouteInformation>> discoveredRoutes) {
		this.discoveredRoutes = discoveredRoutes;
	}

	public NetworkResourceEngine getNRE() {
		return nre;
	}

	public Map<Integer, Demand> getDemandList() {
		return demandList;
	}

	public Demand getDemand(int key)
	{
		return demandList.get(key);
	}

	public void setDemandList(Map<Integer, Demand> demandList) {
		this.demandList = demandList;
	}

	public void printAllDemandList()
	{
		String printOut = "";
		boolean result;
		String linkProperty;
		int linkHeadResidualCapacity = -1;
		int linkTailResidualCapacity = -1;
		for(Demand thisDemand : demandList.values())
		{

			printOut += "=========================="+"\n";
			printOut += "Demand "+thisDemand.getId()+"\n";
			printOut += "\t Source Node "+thisDemand.getSource().getNodeID()+"\n";
			printOut += "\t Destination Node "+thisDemand.getDestination().getNodeID()+"\n";
			printOut += "\t Status "+thisDemand.getStatus()+"\n";
			printOut += "\t Magnitude "+thisDemand.getMagnitude()+"\n";
			printOut += "\t Usage "+thisDemand.getDemandUsage()+"\n";
			if(thisDemand.getCarriedTraffic().size()>0)
			{
				printOut += "\t Flow "+"\n";
				for(Flow thisFlow : thisDemand.getCarriedTraffic())
				{
					linkProperty = "";
					result = true;
					printOut += "\t\t Magnitude "+thisFlow.getMagnitude()+"\n";
					printOut += "\t\t Delay "+thisFlow.getDelay()+"\n";
					printOut += "\t\t Status "+thisFlow.getStatus()+"\n";
					printOut += "\t\t === \n";
					for(Link currLink : thisFlow.getPath())
					{
						// check if this link type to determine whose residual capacity should be checked
						if(currLink.getLinkType().equals("Circuit"))
						{
							linkHeadResidualCapacity = currLink.getHead().getOpticalCircuitSwitchResidualCapacity();
							linkTailResidualCapacity = currLink.getTail().getOpticalCircuitSwitchResidualCapacity();
						}
						if(currLink.getLinkType().equals("Packet"))
						{
							linkHeadResidualCapacity = currLink.getHead().getOpticalPacketSwitchResidualCapacity();
							linkTailResidualCapacity = currLink.getTail().getOpticalPacketSwitchResidualCapacity();
						}
						if(result)
						{
							printOut += "\t\t Node "+(currLink.getHead().getNodeID())+" with a "+
									"residual capacity of "+ linkHeadResidualCapacity+"\n";
							result = false;
						}
						linkProperty += currLink.getLinkType()+"-";
						printOut += "\t\t Node "+(currLink.getTail().getNodeID())+" with a "+
								"residual capacity of "+ linkTailResidualCapacity+"\n";
						printOut += "\t\t Link between "+(currLink.getHead().getNodeID())+" and "+
								(currLink.getTail().getNodeID())+" has a "+"residual capacity of "
								+ (currLink.getLinkResidualCapacity())+"\n";
					}
					linkProperty = linkProperty.substring(0, linkProperty.length()-1);
					printOut += "\n\t\t Link Property "+linkProperty+"\n";
					printOut += "\n";

				}
			}
		}
		printOut += "=========================="+"\n";
		System.out.println(printOut);
	}
}
