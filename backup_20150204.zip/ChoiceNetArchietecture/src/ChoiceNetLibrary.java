import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class ChoiceNetLibrary {
	
	private static ChoiceNetLibrary instance = new ChoiceNetLibrary();
	TokenManager tokenMgr = TokenManager.getInstance();
	AdvertisementManager adMgr = AdvertisementManager.getInstance();
	
	public static ChoiceNetLibrary getInstance() 
	{
		return instance;
	}

	// 	========================== XML Reader ================================
	
	public ChoiceNetMessageField parseAdvertisementXML(String filename)
	{
		ChoiceNetMessageField advertisement = null;
		try {
			File fXmlFile = new File(filename);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
	
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
	
			System.out.println("Root element:" + doc.getDocumentElement().getNodeName());
	
			NodeList nList = doc.getElementsByTagName("advertisement");
			int advertisementCount = nList.getLength();
			System.out.println("----------------------------");
			NodeList myList = null;
			Node myNode = null;
			Element myElement = null;
			System.out.println(">>> XML "+filename);
			int considerationValue = 0;
			String considerationMethod, cValue, economyPlaneAddressScheme, economyPlaneAddressValue, usePlaneAddressScheme, usePlaneAddressValue, advertiserName, serviceName, serviceType, 
			serviceDescription, propertyName, propertyValue, srcAddressScheme, srcAddressValue, dstAddressScheme, dstAddressValue;
			considerationMethod = cValue = economyPlaneAddressScheme = economyPlaneAddressValue = usePlaneAddressScheme = usePlaneAddressValue = advertiserName = serviceName = serviceType = serviceDescription =  
			propertyName = propertyValue = srcAddressScheme = srcAddressValue = dstAddressScheme = dstAddressValue = null;
			for (int temp = 0; temp < advertisementCount; temp++) {
	
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					myList = doc.getElementsByTagName("consideration");
					myNode = myList.item(temp);
					if (myNode.getNodeType() == Node.ELEMENT_NODE) {
						myElement = (Element) myNode;
						considerationMethod = myElement.getElementsByTagName("method").item(0).getTextContent();
						cValue = myElement.getElementsByTagName("value").item(0).getTextContent();
						considerationValue = Integer.parseInt(cValue);
					}
					// Economy Plane Information
					myList = doc.getElementsByTagName("economyPlane");
					myNode = myList.item(temp);
					if (myNode.getNodeType() == Node.ELEMENT_NODE) {
						myElement = (Element) myNode;
						economyPlaneAddressScheme = myElement.getElementsByTagName("addressingScheme").item(0).getTextContent();
						economyPlaneAddressValue = myElement.getElementsByTagName("addressingValue").item(0).getTextContent();
						advertiserName = myElement.getElementsByTagName("advertiserName").item(0).getTextContent();
					}
					// Use Plane Information
					myList = doc.getElementsByTagName("usePlane");
					myNode = myList.item(temp);
					if (myNode.getNodeType() == Node.ELEMENT_NODE) {
						myElement = (Element) myNode;
						usePlaneAddressScheme = myElement.getElementsByTagName("addressingScheme").item(0).getTextContent();
						usePlaneAddressValue = myElement.getElementsByTagName("addressingValue").item(0).getTextContent();
					}
					// Service Information
					myList = doc.getElementsByTagName("service");
					myNode = myList.item(temp);
					if (myNode.getNodeType() == Node.ELEMENT_NODE) {
						myElement = (Element) myNode;
						serviceName =  myElement.getElementsByTagName("name").item(0).getTextContent();
						serviceType =  myElement.getElementsByTagName("type").item(0).getTextContent();
						serviceDescription =  myElement.getElementsByTagName("description").item(0).getTextContent();//						
						// Property
						myList = doc.getElementsByTagName("property");
						myNode = myList.item(temp);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							myElement = (Element) myNode;
							propertyName = myElement.getElementsByTagName("name").item(0).getTextContent();
							propertyValue = myElement.getElementsByTagName("value").item(0).getTextContent();
						}
						// Location (Source)
						myList = doc.getElementsByTagName("srcLocation");
						myNode = myList.item(temp);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							myElement = (Element) myNode;
							srcAddressScheme = myElement.getElementsByTagName("addressingScheme").item(0).getTextContent();
							srcAddressValue = myElement.getElementsByTagName("addressingValue").item(0).getTextContent();
						}
						// Location (Destination)
						myList = doc.getElementsByTagName("dstLocation");
						myNode = myList.item(temp);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							myElement = (Element) myNode;
							dstAddressScheme = myElement.getElementsByTagName("addressingScheme").item(0).getTextContent();
							dstAddressValue = myElement.getElementsByTagName("addressingValue").item(0).getTextContent();
						}
						
						// Print Out
						String printOut = "Advertisement \n" +
								"Economy Plane Addressing Scheme: "+economyPlaneAddressScheme+"\n" +
								"Economy Plane Addressing Value: "+economyPlaneAddressValue+"\n" +
								"Service Name: "+serviceName+"\n";
						System.out.println(printOut);
						
					}
					int advertiserPortAddress = -1;
					String advertiserAddress = "";
					if(economyPlaneAddressScheme.equals("UDPv4") || economyPlaneAddressScheme.equals("TCPv4"))
					{
						String[] addr = economyPlaneAddressValue.split(":");
						advertiserAddress = addr[0];
						advertiserPortAddress = Integer.parseInt(addr[1]);
					}
					ServiceProperty sProp = new ServiceProperty(propertyName, propertyValue);
					ServiceProperty serviceProperties[] = {sProp};
					Service myService = new Service(serviceName, serviceType, srcAddressScheme, srcAddressValue, dstAddressScheme, dstAddressValue, serviceProperties, serviceDescription);
					Advertisement myAd = new Advertisement(considerationMethod, considerationValue, advertiserName, myService, advertiserAddress, advertiserPortAddress, economyPlaneAddressScheme, -1,usePlaneAddressScheme,usePlaneAddressValue);
					adMgr.addAdvertisement(myAd);
					advertisement = createAdvertisement(considerationMethod, considerationValue, economyPlaneAddressScheme, economyPlaneAddressValue, advertiserName, serviceName, serviceType, serviceDescription, propertyName, propertyValue, srcAddressScheme, srcAddressValue, dstAddressScheme, dstAddressValue);
				}
			}
		} catch (Exception e) {
			Server.systemMessage = e.getMessage();
			//e.printStackTrace();
		}
		System.out.println("----------------------------");
		return advertisement;
	}

	public String getServiceNameFromAdvertisementXML(String filename)
	{
		String serviceName = "";
		try {
			File fXmlFile = new File(filename);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
	
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
	
			System.out.println("Root element:" + doc.getDocumentElement().getNodeName());
	
			NodeList nList = doc.getElementsByTagName("advertisement");
			int advertisementCount = nList.getLength();
			System.out.println("----------------------------");
			NodeList myList = null;
			Node myNode = null;
			Element myElement = null;
			for (int temp = 0; temp < advertisementCount; temp++) {
	
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					// Service Information
					myList = doc.getElementsByTagName("service");
					myNode = myList.item(temp);
					if (myNode.getNodeType() == Node.ELEMENT_NODE) {
						myElement = (Element) myNode;
						serviceName =  myElement.getElementsByTagName("name").item(0).getTextContent();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("----------------------------");
		return serviceName;
	}
	
	public ChoiceNetMessageField createAdvertisement(String considerationMethod, int considerationValue, 
			String addrSchemeVal, String addrVal, String advertiserName,
			String name, String type, String description, String pName, String pValue, 
			String srcAddrScheme, String srcAddrVal, String dstAddrScheme, String dstAddrVal)
	{
		// Service Object
		ChoiceNetMessageField service = createService(name, type, description, pName, pValue, srcAddrScheme, srcAddrVal, dstAddrScheme, dstAddrVal);
		// Consideration
//		ChoiceNetMessageField cMethod = new ChoiceNetMessageField("Consideration Method", considerationMethod, "");
//		ChoiceNetMessageField cValue = new ChoiceNetMessageField("Consideration Value", considerationValue, "");
//		ChoiceNetMessageField[] cPayload = {cMethod,cValue};  
//		ChoiceNetMessageField consideration = new ChoiceNetMessageField("Consideration", cPayload, "");
		ChoiceNetMessageField cPayload = new ChoiceNetMessageField(considerationMethod, considerationValue, "");
		ChoiceNetMessageField consideration = new ChoiceNetMessageField("Consideration", cPayload, "");
		// Provider Economy Plane Address
		ChoiceNetMessageField addressingScheme = new ChoiceNetMessageField("Addressing Scheme", addrSchemeVal, "");
		ChoiceNetMessageField addressingValue = new ChoiceNetMessageField("Addressing Value", addrVal, "");
		ChoiceNetMessageField entityName = new ChoiceNetMessageField("Entity's Name", advertiserName, "");
		ChoiceNetMessageField[] value = {addressingScheme,addressingValue,entityName};
		ChoiceNetMessageField economyAddress = new ChoiceNetMessageField("Provider Economy Plane Address", value, "");
		// Advertisement Object
		ChoiceNetMessageField[] payload = {service,consideration,economyAddress};
		ChoiceNetMessageField advertisement = new ChoiceNetMessageField("Advertisement", payload, "");
		return advertisement;
	}

	/**
	 * Create Service Object
	 * 
	 * @param name
	 * @param type
	 * @param description
	 * @param pName
	 * @param pValue
	 * @param srcAddrScheme
	 * @param srcAddrVal
	 * @param dstAddrScheme
	 * @param dstAddrVal
	 * @return
	 */
	public ChoiceNetMessageField createService(String name, String type, String description, 
			String pName, String pValue, String srcAddrScheme, String srcAddrVal, String dstAddrScheme, String dstAddrVal)
	{
		ChoiceNetMessageField serviceName = new ChoiceNetMessageField("Service Name", name, "");
		ChoiceNetMessageField serviceType = new ChoiceNetMessageField("Service Type", type, "");
		ChoiceNetMessageField serviceDescription = new ChoiceNetMessageField("Description", description, "");
		// Service Specific Value
		ChoiceNetMessageField propertyName = new ChoiceNetMessageField("Property Name", pName, "");
		ChoiceNetMessageField propertyValue = new ChoiceNetMessageField("Property Value", pValue, "");
		ChoiceNetMessageField[] property = {propertyName,propertyValue};
		ChoiceNetMessageField serviceProperty = new ChoiceNetMessageField("Service Specific Property", property, "");
		// Location (Source)
		ChoiceNetMessageField srcLocScheme = new ChoiceNetMessageField("Addressing Scheme", srcAddrScheme, "");
		ChoiceNetMessageField srcLocVal = new ChoiceNetMessageField("Addressing Value", srcAddrVal, "");
		ChoiceNetMessageField[] srcLocationVal = {srcLocScheme,srcLocVal};
		ChoiceNetMessageField srcLocation = new ChoiceNetMessageField("Location", srcLocationVal, "");
		// Location (Destination)
		ChoiceNetMessageField dstLocScheme = new ChoiceNetMessageField("Addressing Scheme", dstAddrScheme, "");
		ChoiceNetMessageField dstLocVal = new ChoiceNetMessageField("Addressing Value", dstAddrVal, "");
		ChoiceNetMessageField[] dstLocationVal = {dstLocScheme,dstLocVal};
		ChoiceNetMessageField dstLocation = new ChoiceNetMessageField("Location", dstLocationVal, "");
		ChoiceNetMessageField[] payload = {serviceName,serviceType,serviceDescription,serviceProperty,srcLocation,dstLocation};
		
		ChoiceNetMessageField service = new ChoiceNetMessageField("Service", payload, "");
		return service;
	}
	
	public ChoiceNetMessageField createToken(String issuedToVal, String myName, String sName, long eTime)
	{
		int tID = tokenMgr.createTokenID();
		ChoiceNetMessageField tokenID = new ChoiceNetMessageField("Token ID", tID, "");
		ChoiceNetMessageField issuedTo = new ChoiceNetMessageField("Issued To", issuedToVal, "");
		ChoiceNetMessageField issuedBy = new ChoiceNetMessageField("Issued By", myName, "");
		// convert from minutes to milliseconds
		eTime = System.currentTimeMillis()+(eTime*60000);
		ChoiceNetMessageField expirationTme = new ChoiceNetMessageField("Expiration Time", eTime, "");
		ChoiceNetMessageField serviceName = new ChoiceNetMessageField("Service Name", sName, "");
		ChoiceNetMessageField[] payload = {tokenID,issuedTo,issuedBy,serviceName,expirationTme};
		
		ChoiceNetMessageField token = new ChoiceNetMessageField("Token", payload, "");
		return token;
	}
	
	public Advertisement extractAdvertisementContent(ChoiceNetMessageField advertisement, long expirationTime)
	{
		ChoiceNetMessageField[] tPayload;
		ChoiceNetMessageField[] payload = (ChoiceNetMessageField[]) advertisement.getValue();
		ChoiceNetMessageField myService = (ChoiceNetMessageField) payload[0];
		Service service = extractServiceContent(myService); 
		// Consideration
		ChoiceNetMessageField consideration = (ChoiceNetMessageField) payload[1];
//		tPayload = (ChoiceNetMessageField[]) consideration.getValue();
//		String considerationMethod = (String) tPayload[0].getValue();
//		int considerationValue = (Integer) tPayload[1].getValue();
		ChoiceNetMessageField contents = (ChoiceNetMessageField) consideration.getValue();
		String considerationMethod = (String) contents.getAttributeName();
		int considerationValue = (Integer) contents.getValue();
		ChoiceNetMessageField economyAddrProp = (ChoiceNetMessageField) payload[2];
		tPayload = (ChoiceNetMessageField[]) economyAddrProp.getValue();
		String advertiserAddressScheme = (String) tPayload[0].getValue();
		String advertiserAddress = (String) tPayload[1].getValue();
		int advertiserPortAddress = -1;
		if(advertiserAddressScheme.equals("UDPv4") || advertiserAddressScheme.equals("TCPv4"))
		{
			String[] addr = advertiserAddress.split(":");
			advertiserAddress = addr[0];
			advertiserPortAddress = Integer.parseInt(addr[1]);
		}
		String entityName = (String) tPayload[2].getValue();
		Advertisement myAd = new Advertisement(considerationMethod, considerationValue, entityName, service, advertiserAddress, advertiserPortAddress, advertiserAddressScheme, expirationTime, null,null);
		
		return myAd;
	}
	
	public Service extractServiceContent(ChoiceNetMessageField service) {
		ChoiceNetMessageField[] tPayload;
		ChoiceNetMessageField[] payload = (ChoiceNetMessageField[]) service.getValue();
		String name = (String) payload[0].getValue();
		String type = (String) payload[1].getValue();
		String description = (String) payload[2].getValue();

		ChoiceNetMessageField property = (ChoiceNetMessageField) payload[3];
		tPayload = (ChoiceNetMessageField[]) property.getValue();
		// should loop around as an array

		String propertyType = (String) tPayload[0].getValue();
		String propertyValue = (String) tPayload[1].getValue();
		ServiceProperty sProp = new ServiceProperty(propertyType, propertyValue);
		ServiceProperty serviceProperties[] = {sProp};
		
		ChoiceNetMessageField srcLocation = (ChoiceNetMessageField) payload[4];
		tPayload = (ChoiceNetMessageField[]) srcLocation.getValue();
		String srcLocationAddrScheme = (String) tPayload[0].getValue();
		String srcLocationAddrValue = (String) tPayload[1].getValue();
		
		ChoiceNetMessageField dstLocation = (ChoiceNetMessageField) payload[5];
		tPayload = (ChoiceNetMessageField[]) dstLocation.getValue();
		String dstLocationAddrScheme = (String) tPayload[0].getValue();
		String dstLocationAddrValue = (String) tPayload[1].getValue();
		
		Service myService = new Service(name, type, srcLocationAddrScheme, srcLocationAddrValue, dstLocationAddrScheme, dstLocationAddrValue, serviceProperties, description);
		return myService;
	}

	public Token extractTokenContent (ChoiceNetMessageField token)
	{
		ChoiceNetMessageField[] payload = (ChoiceNetMessageField[]) token.getValue();
		int tokenID = (Integer) payload[0].getValue();
		String issuedTo = (String) payload[1].getValue();
		String issuedBy = (String) payload[2].getValue();
		String serviceName = (String) payload[3].getValue();
		long expirationTime = (Long) payload[4].getValue();
		Token myToken = new Token(tokenID, issuedTo, issuedBy, serviceName, expirationTime);
		return myToken;
	}
}
