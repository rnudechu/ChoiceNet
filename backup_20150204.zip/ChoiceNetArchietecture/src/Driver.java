
public class Driver {

	
	public static void main(String[] args) 
	{

		FlowManager fm = new FlowManager();
		Demand requestedResource;
		Node[] allNodes = fm.getNRE().getNodeArray();
		Node source, destination;
		
		//		fm.reloadSystem();
		//		fm.printAllDemandList();
		//		fm.saveSystem();

		
		source = allNodes[3];
		destination = allNodes[2];
		requestedResource = new Demand(source,destination,50);
		System.out.println(requestedResource);
		//fm.findAvailableRoute(requestedResource, null, "", "Packet","");
//		fm.findAvailableRoute(requestedResource, null, "", "Circuit","");
//		System.out.println(fm.getDiscoveredRoutes());
//		//fm.printAllDemandList();
		fm.enterRequestedDemand(requestedResource, "Circuit");
//		fm.printAllDemandList();



		while(true)
		{
			// Generate random demands - 20% possibility
			if(fm.getDemandList().size()<10)
			{
				fm.generateRandomDemand();
			}
			// check demandList for expired demands
			// 	delete their flow freeing up resources
			fm.removeExpiredDemands();
		}
		// TODO: dumping/reading to the config 
		//		System.out.println(fm.getDiscoveredRoutes());
		//		fm.installFlow("4-2-1:10");
		//		fm.installFlow("4-2-1-3:10");
		//		fm.deleteFlow("4-2-1:5");
		//		fm.installFlow("1-2-4-8-9-7:10");
		//		fm.installFlow("3-1-2-4-8-9-7:50");
		//		fm.installFlow("1-2-3:50");
		//		fm.findAvailableRoute(1, 3, 10, null,"");
		//		fm.findAvailableRoute(4, 1, 10, null,"");
		//		fm.findAvailableRoute(4, 3, 10, null,"");
		//		fm.loadRoutes();

	}

}
