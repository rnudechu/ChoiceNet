
public class RouteInformation {

	private String routes;
	private String linkType;
	private String property;
	public RouteInformation(String routes, String linkType) {
		super();
		this.routes = routes;
		this.linkType = linkType;
		determineProperty();
	}
	public String getRoutes() {
		return routes;
	}
	public void setRoutes(String routes) {
		this.routes = routes;
	}
	public String getLinkType() {
		return linkType;
	}
	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}
	public void determineProperty() 
	{
		String linkType = getLinkType();
		String[] attributes = linkType.split("-");
		// count the number of C
		int countC = 0;
		int countP = 0;
		// count the number of P
		for (int i=0; i < attributes.length; i++)
	    {
	        if (attributes[i].equals("C"))
	        {
	             countC++;
	        }
	        if (attributes[i].equals("P"))
	        {
	             countP++;
	        }
	    }
		// if either count is zero then set the property the characteristic
		if(countC == 0 || countP == 0)
		{
			if(countC == 0)
			{
				setProperty("Packet");
			}
			if(countP == 0)
			{
				setProperty("Circuit");
			}
		}
		// else set to mix
		else			
		{
			setProperty("Mixed");
		}
	}
	
	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	@Override
	public String toString() {
		return "RouteInformation [routes=" + routes + ", linkType=" + linkType
				+ ", property=" + property + "]";
	}

}
